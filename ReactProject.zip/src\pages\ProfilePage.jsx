import { useEffect, useState } from "react";
import "./ProfilePage.css";
import { useNavigate } from "react-router-dom";
import { authService, profilesService, skillsService, portfolioService, reviewsService } from "../services/api";

import ProfileHeader from "../components/ProfileHeader";
import ProfileTabs from "../components/ProfileTabs";
import ProfileSidebar from "../components/ProfileSidebar";
import ProfileAboutCard from "../components/ProfileAboutCard";
import ProfileSkillsCard from "../components/ProfileSkillsCard";
import ProfileFeaturedWorkCard from "../components/ProfileFeaturedWorkCard";
import ProfileBottomCta from "../components/ProfileBottomCta";

export default function ProfilePage() {
  const navigate = useNavigate();
  const [userData, setUserData] = useState(null);
  const [profileData, setProfileData] = useState(null);
  const [apiSkills, setApiSkills] = useState([]);
  const [portfolioItems, setPortfolioItems] = useState([]);
  const [reviews, setReviews] = useState([]);
  const [loading, setLoading] = useState(true);

  const userId = localStorage.getItem("userId");

  useEffect(() => {
    Promise.all([
      authService.me().catch(() => null),
      profilesService.me().catch(() => null),
      skillsService.mySkills().catch(() => []),
      portfolioService.my().catch(() => []),
      userId ? reviewsService.mine().catch(() => []) : Promise.resolve([]),
    ]).then(([user, profile, skills, portfolio, revs]) => {
      setUserData(user);
      setProfileData(profile);
      setApiSkills(Array.isArray(skills) ? skills : []);
      setPortfolioItems(Array.isArray(portfolio) ? portfolio : []);
      setReviews(Array.isArray(revs) ? revs : []);
    }).finally(() => setLoading(false));
  }, [userId]);

  const handleAddSkill = async () => {
    // Search for skill first
    const skillName = window.prompt("Enter skill name to search and add:");
    if (!skillName) return;
    try {
      const results = await skillsService.search(skillName);
      const list = Array.isArray(results) ? results : [];
      if (list.length === 0) {
        alert("Skill not found. Try a different name.");
        return;
      }
      const skill = list[0];
      const level = Number(window.prompt(`Add "${skill.nameEn || skill.name}" — Proficiency level (0=Beginner, 1=Intermediate, 2=Advanced, 3=Expert):`, "1"));
      const years = Number(window.prompt("Years of experience:", "1"));
      await skillsService.addMySkill(skill.id, level, years);
      const updated = await skillsService.mySkills();
      setApiSkills(Array.isArray(updated) ? updated : []);
    } catch (err) {
      alert(err.message || "Error adding skill.");
    }
  };

  const handleDeleteSkill = async (skillId) => {
    if (!window.confirm("Remove this skill?")) return;
    try {
      await skillsService.deleteMySkill(skillId);
      setApiSkills((prev) => prev.filter((s) => s.skillId !== skillId && s.id !== skillId));
    } catch (err) {
      alert(err.message || "Error removing skill.");
    }
  };

  function handleReturn() {
    if (window.history.length > 1) { navigate(-1); return; }
    navigate("/dashboard");
  }

  const storedName = localStorage.getItem("authUserName");

  const fullName = userData
    ? ([userData.firstName, userData.lastName].filter(Boolean).join(" ").trim() || userData.fullName || storedName || "User")
    : (storedName || "User");

  const avgRating = reviews.length
    ? (reviews.reduce((sum, r) => sum + (r.rating || 0), 0) / reviews.length).toFixed(2)
    : "N/A";

  const profile = {
    avatarUrl: userData?.profileImageUrl || profileData?.profileImageUrl || "/images/shadow-avatar.svg",
    name: fullName,
    verified: userData?.isEmailVerified || false,
    roleTitle: profileData?.title || "Freelancer",
    availableText: profileData?.isAvailable ? "Available now" : "Not available",
    metaRow: [
      profileData?.country && { icon: "fas fa-map-marker-alt", text: profileData.country },
    ].filter(Boolean),
    actions: { hireText: "Hire Now" },
    tabs: [
      { label: "Overview" },
      { label: `Portfolio (${portfolioItems.length})` },
      { label: `Reviews (${reviews.length})` },
    ],
    activeTab: "Overview",

    scoreCard: {
      headerText: "AI PROFILE SCORE",
      percent: 0, // will be loaded by AI if desired
      label: "PROFILE",
      topText: "Complete your profile to improve your score",
      bars: [
        { icon: "fas fa-desktop", title: "Skills", value: apiSkills.length > 0 ? Math.min(apiSkills.length * 10, 100) : 0 },
        { icon: "fas fa-briefcase", title: "Portfolio", value: portfolioItems.length > 0 ? Math.min(portfolioItems.length * 20, 100) : 0 },
        { icon: "fas fa-star", title: "Reviews", value: reviews.length > 0 ? Math.min(reviews.length * 15, 100) : 0 },
      ],
    },

    stats: [
      { icon: "fas fa-star", value: avgRating, title: "RATING", sub: `${reviews.length} reviews` },
      { icon: "fas fa-file", value: String(portfolioItems.length), title: "PORTFOLIO", sub: "items" },
      { icon: "fas fa-tools", value: String(apiSkills.length), title: "SKILLS", sub: "added" },
      { icon: "fas fa-check-circle", value: userData?.isEmailVerified ? "Yes" : "No", title: "VERIFIED", sub: "email" },
    ],

    hourlyRate: {
      rate: profileData?.hourlyRate ? String(profileData.hourlyRate) : "--",
      responseTime: "< 2 hours",
      memberSince: userData?.createdAt ? new Date(userData.createdAt).toLocaleDateString("en-US", { month: "short", year: "numeric" }) : "--",
      languages: "—",
    },
    sendMessageLabel: "Send Message",

    about: {
      title: "About",
      description: profileData?.bio || "No bio yet.",
      description2: "",
    },

    skills: {
      title: "Skills & Expertise",
      subtitle: "Your added skills",
      chips: apiSkills.map((s) => ({ id: s.skillId || s.id, name: s.skillName || s.nameEn || s.name, level: s.proficiencyLevel })),
      onAdd: handleAddSkill,
      onDelete: handleDeleteSkill,
    },

    featuredWork: {
      title: "Portfolio",
      subtitle: "Your recent work",
      rightLinkText: "",
      items: portfolioItems.slice(0, 4).map((item) => ({
        pillLabel: "Project",
        imageUrl: item.imageUrl || "/images/profile1.jpg",
        title: item.title,
        description: item.description || "",
        tags: [],
        liveUrl: item.liveUrl || item.url,
      })),
    },

    bottomCta: {
      title: `Work with ${fullName.split(" ")[0]}?`,
      subtitle: profileData?.isAvailable ? "Available for new projects now." : "Currently not available.",
      buttonText: "Hire Now",
    },
  };

  if (loading) {
    return (
      <div className="profilePage" style={{ display: "flex", alignItems: "center", justifyContent: "center", minHeight: "60vh" }}>
        <p style={{ color: "#aaa" }}>Loading profile...</p>
      </div>
    );
  }

  return (
    <div className="profilePage">
      <div className="profilePage__topActions">
        <button type="button" className="profilePage__backBtn" onClick={handleReturn}>
          <i className="fa-solid fa-arrow-left" aria-hidden="true" />
          Return
        </button>
      </div>

      <ProfileHeader profile={profile} />

      <div className="profilePage__contentWrap">
        <div className="profilePage__layout">
          <aside className="profilePage__sidebar">
            <ProfileSidebar profile={profile} />
          </aside>
          <main className="profilePage__main">
            <ProfileTabs tabs={profile.tabs} active={profile.activeTab} />
            <div className="profilePage__cards">
              <ProfileAboutCard about={profile.about} />
              <ProfileSkillsCard skills={profile.skills} />
              <ProfileFeaturedWorkCard work={profile.featuredWork} />
            </div>
          </main>
        </div>
      </div>

      <ProfileBottomCta cta={profile.bottomCta} />
    </div>
  );
}
